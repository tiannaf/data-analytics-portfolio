# custom library with welcome function, classes used for the exercise data, and constant
# creating a welcome function
def welcome():
    print('Welcome to Bake it Till You Make It! A sweet treat awaits you...')
    print('First, here is a little preview of 4-star rating cakes and cupcakes!')

# class for Equipment and object orientation
# inspired by homework/slides
class Equipment:
        def __init__(self, equipment_name, equipment_quantity):
            self.equipment_name = equipment_name
            self.equipment_quantity = equipment_quantity

# class for Dumbbell/inheritance - will show quantity of equipment and weight
class Dumbbell(Equipment):
        def __init__(self, equipment_name, equipment_quantity, weight):
            super().__init__(equipment_name, equipment_quantity)
            self.weight = weight

# class for Kettlebell/inheritance - will show quantity of equipment and weight
class Kettlebell(Equipment):
    def __init__(self, equipment_name, equipment_quantity, weight):
        super().__init__(equipment_name, equipment_quantity)
        self.weight = weight

# class for Barbell/inheritance - will show quantity of equipment and weight
class Barbell(Equipment):
    def __init__(self, equipment_name, equipment_quantity, weight):
        super().__init__(equipment_name, equipment_quantity)
        self.weight = weight

# sets quantity and weight in pounds for all equipment
dumbbell = Dumbbell("Dumbbell", 2, 15)
kettlebell = Kettlebell("Kettlebell", 1, 25)
barbell = Barbell("Barbell", 1, 40)

# constant
Constant = "Enjoy your sweet treat and workout!"
print(Constant)






