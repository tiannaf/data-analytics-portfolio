# import from standard pandas library
import pandas as pd
from myfinallibrary import welcome

# create file for writing results
out_file = open("results.txt", "w", encoding='utf-8')

# reads the dessert csv file
df1 = pd.read_csv('dessertdataset.csv')
print(welcome())
# calculate and display top cakes/cupcakes before prompting flavors with rating 4
top_cakes = df1[df1['rating'] == 4]
top_cakes = top_cakes[top_cakes['recipe_name'].str.contains('Cake|cake|CAKE')]
print('Top rated cakes and cupcakes:')
print("{:<70} {:<9}".format("Recipe", "Rating"))
for ind in top_cakes.index:
    print("{:<70} {:<9}".format(top_cakes['recipe_name'][ind], top_cakes['rating'][ind]))
print('**************************************************************')
# define flavors
flavors = []
print('Time to find your next favorite dessert...')
# iteration
while True:
    # user types one flavor
    flavors.append(input('Type a dessert flavor: ').lower())
    # user types additional flavors if they choose. loop will stop once they type N
    add_another_flavor = (input('Do you want to add another flavor? Type the flavor or N: '))
    if add_another_flavor.lower() != 'y':
        break

# write dessert header to output file
out_file.write("Desserts:\n")

# prints all dessert combos in data set with those flavor names
print('The dessert combinations you can make are...')
print('Scroll down...there are still workouts to pick!')

# data structure list
df_list = []
for ind in df1.index:
    select_dessert = True
    for selected_flavor in flavors:
        if selected_flavor not in str(df1['flavors'][ind]):
            select_dessert = False
    if select_dessert:
        # write the dessert to the out file
        df_list.append(df1['recipe_name'][ind])

        out_file.write(df1['recipe_name'][ind] + "\n")
# was researching and came across error handling... wanted to give it a try here
try:
    # Pandas dataframe that creates it off a single list of recipe names and outputs to csv file.
    df_test = pd.DataFrame(df_list, columns=['recipe_name'])
    print(df_test.reset_index(drop=True))
    df_test.to_csv("dessert_output.csv", index=False)
except:
    print("The dataframe could not be written, unknown error!")

print('**************************************************************')
# workout data begins here
print('Your dessert results were printed as a separate file on your computer')
print('Before you take a look at those, select a workout!')
# reading the exercise csv
df2 = pd.read_csv('exercisedata.csv')
# data structure lists
major_muscle = []
minor_muscle = []

# iteration
while True:
    # user types one muscle group
    major_muscle.append(input('Type a major muscle group (arms,legs,core,full body,or back:)' ).lower())
    minor_muscle.append(input('Type minor muscle group (glutes,inner thigh,'
    'outer thigh,quads,hamstrings,shoulders, tricep, bicep, chest, or obliques:)').lower())

    # user types additional muscle groups if they choose. loop will stop once they type N
    add_another_major_muscle = (input('Do you want to add another major muscle group? Type the muscle or N: '))
    if add_another_major_muscle.lower() != 'y':
        break
    add_another_minor_muscle = (input('Do you want to add another minor muscle group? Type the muscle part or N: '))
    if add_another_minor_muscle.lower() != 'y':
        break

# write workouts header to output file
out_file.write("\nWorkouts:\n")

# prints all exercises in data set with those muscle group names
print('The exercises you can do are...')
for ind in df2.index:
    select_exercise = True
    if str(df2['Major Muscle'][ind]).lower() not in major_muscle and str(df2['Minor Muscle'][ind]).lower() not in minor_muscle:
        select_exercise = False
    if select_exercise:
        print(df2['Exercise'][ind])
        # write the workout to the outfile
        out_file.write(df2['Exercise'][ind] + "\n")
# importing from my library program
from myfinallibrary import *

# prints the equipment with the quantity and weight in (lbs.) suggestion
print('The workout equipment you can use by quantity and weight suggestion:')
print(dumbbell.equipment_name)
print('quantity needed:',dumbbell.equipment_quantity)
print('weight suggestion:',dumbbell.weight)
print(kettlebell.equipment_name)
print('quantity needed:',kettlebell.equipment_quantity)
print(kettlebell.weight)
print(barbell.equipment_name)
print('quantity needed:',barbell.equipment_quantity)
print('weight suggestion:',barbell.weight)
print('**************************************************************')
print('Check your desktop or file folder- your dessert and workout results were now printed to an output file!')
# close file once program is finished
out_file.close()

# constant from custom library
from myfinallibrary import Constant
print((Constant))



 



 


 


